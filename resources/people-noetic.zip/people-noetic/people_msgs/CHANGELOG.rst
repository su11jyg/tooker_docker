^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package people_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.0 (2019-08-19)
------------------
* Document name field in PositionMeasurement (`#75 <https://github.com/wg-perception/people/issues/75>`_)
* Cleanup (`#73 <https://github.com/wg-perception/people/issues/73>`_)
  * Fill in implied packages
  * Misc Whitespace cleanup
* Contributors: David V. Lu!!, Shane Loretz

1.0.9 (2015-09-01)
------------------

1.0.8 (2014-12-10)
------------------

1.0.3 (2014-03-01)
------------------

1.0.2 (2014-02-28)
------------------

1.0.1 (2014-02-27)
------------------
* catkinizing
* Contributors: Dan Lazewatsky
