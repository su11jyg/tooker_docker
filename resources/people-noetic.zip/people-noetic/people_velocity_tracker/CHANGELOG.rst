^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package people_velocity_tracker
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.0 (2019-08-19)
------------------
* Whitespace cleanup (`#73 <https://github.com/wg-perception/people/issues/73>`_)
* Contributors: David V. Lu!!

1.0.9 (2015-09-01)
------------------
* change queue sizes to 10
* Update for Indigo and add unfiltered people velocity launcher
* PEP8 fixes
* Contributors: Aaron Blasdel

1.0.8 (2014-12-10)
------------------

1.0.4 (2014-07-09)
------------------
* Merging people_velocity_tracker into people
* Contributors: David Lu!!

1.0.3 (2014-03-01)
------------------

1.0.2 (2014-02-28)
------------------

1.0.1 (2014-02-27)
------------------
